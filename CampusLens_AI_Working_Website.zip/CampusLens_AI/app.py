import os, re, sqlite3
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import check_password_hash
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "local-dev-key-change-before-deploy")
DB_PATH = os.getenv("DATABASE_PATH", os.path.join(os.path.dirname(__file__), "campuslens.db"))
ADMIN_PASSWORD_HASH = os.getenv("ADMIN_PASSWORD_HASH", "")
CATEGORIES = ["Accessibility", "Maintenance", "Sanitation", "Safety", "Other"]
STATUSES = ["Submitted", "In progress", "Resolved"]

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, description TEXT NOT NULL, location TEXT NOT NULL,
            category TEXT NOT NULL, ai_category TEXT NOT NULL,
            urgency INTEGER NOT NULL, accessibility INTEGER NOT NULL,
            disruption INTEGER NOT NULL, recurrence INTEGER NOT NULL,
            priority INTEGER NOT NULL, reason TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Submitted', created_at TEXT NOT NULL)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS history(
            id INTEGER PRIMARY KEY AUTOINCREMENT, report_id INTEGER NOT NULL,
            status TEXT NOT NULL, note TEXT NOT NULL, changed_at TEXT NOT NULL,
            FOREIGN KEY(report_id) REFERENCES reports(id))""")

def classify(text):
    text = text.lower()
    rules = {
        "Accessibility": ["ramp", "wheelchair", "accessible", "lift", "elevator", "stairs", "mobility", "blind"],
        "Sanitation": ["garbage", "waste", "dustbin", "dirty", "toilet", "sanitation", "overflowing bin"],
        "Safety": ["fire", "electric shock", "unsafe", "smoke", "hazard", "broken glass", "exposed cable"],
        "Maintenance": ["broken", "leak", "fan", "light", "projector", "desk", "chair", "tap", "door", "window"]
    }
    scores = {category: sum(word in text for word in words) for category, words in rules.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] else "Other"

def score(urgency, accessibility, disruption, recurrence):
    value = round(.40 * urgency + .30 * accessibility + .20 * disruption + .10 * recurrence)
    reasons = []
    if urgency >= 70: reasons.append("high reported urgency")
    if accessibility >= 70: reasons.append("significant accessibility impact")
    if disruption >= 70: reasons.append("possible safety or service disruption")
    if recurrence >= 70: reasons.append("repeated occurrence")
    return max(0, min(100, value)), ", ".join(reasons) if reasons else "routine impact ratings"

def find_similar(location, title, description):
    terms = set(re.findall(r"[a-z]{4,}", f"{title} {description}".lower()))
    if not terms: return []
    with db() as conn:
        rows = conn.execute("SELECT id,title,description,status FROM reports WHERE lower(location)=lower(?) ORDER BY id DESC LIMIT 30", (location,)).fetchall()
    out = []
    for row in rows:
        old = set(re.findall(r"[a-z]{4,}", f"{row['title']} {row['description']}".lower()))
        overlap = len(terms & old) / max(1, len(terms | old))
        if overlap >= .25: out.append(dict(row))
    return out[:3]

def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("admin"): return redirect(url_for("admin_login", next=request.path))
        return fn(*args, **kwargs)
    return wrapped

@app.context_processor
def globals_for_templates():
    return {"categories": CATEGORIES, "statuses": STATUSES}

@app.route("/")
def home():
    with db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
        open_count = conn.execute("SELECT COUNT(*) FROM reports WHERE status!='Resolved'").fetchone()[0]
        resolved = conn.execute("SELECT COUNT(*) FROM reports WHERE status='Resolved'").fetchone()[0]
        recent = conn.execute("SELECT id,title,location,ai_category,priority,status,created_at FROM reports ORDER BY id DESC LIMIT 5").fetchall()
    return render_template("index.html", total=total, open_count=open_count, resolved=resolved, recent=recent)

@app.route("/report", methods=["GET", "POST"])
def report():
    if request.method == "POST":
        title = request.form.get("title", "").strip()[:100]
        description = request.form.get("description", "").strip()[:1500]
        location = request.form.get("location", "").strip()[:120]
        category = request.form.get("category", "Other")
        try:
            urgency, accessibility, disruption, recurrence = [int(request.form.get(k, d)) for k, d in
                [("urgency", 50), ("accessibility", 0), ("disruption", 30), ("recurrence", 0)]]
        except ValueError:
            flash("Please provide valid impact ratings.", "danger")
            return render_template("report.html", form=request.form)
        if not title or not description or not location:
            flash("Title, description, and campus location are required.", "danger")
            return render_template("report.html", form=request.form)
        if category not in CATEGORIES or any(x < 0 or x > 100 for x in [urgency, accessibility, disruption, recurrence]):
            flash("Choose a valid category and ratings from 0 to 100.", "danger")
            return render_template("report.html", form=request.form)
        suggested = classify(title + " " + description)
        priority, reason = score(urgency, accessibility, disruption, recurrence)
        similar = find_similar(location, title, description)
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        with db() as conn:
            cur = conn.execute("""INSERT INTO reports
              (title,description,location,category,ai_category,urgency,accessibility,disruption,recurrence,priority,reason,status,created_at)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,'Submitted',?)""",
              (title, description, location, category, suggested, urgency, accessibility, disruption, recurrence, priority, reason, now))
            rid = cur.lastrowid
            conn.execute("INSERT INTO history(report_id,status,note,changed_at) VALUES(?,?,?,?)", (rid, "Submitted", "Report created", now))
        return render_template("success.html", report_id=rid, suggested=suggested, priority=priority, reason=reason, similar=similar)
    return render_template("report.html", form={})

@app.route("/track", methods=["GET", "POST"])
def track():
    report = None
    history = []
    if request.method == "POST" or request.args.get("id"):
        raw = request.form.get("report_id") or request.args.get("id", "")
        try: rid = int(raw)
        except (TypeError, ValueError):
            flash("Enter a valid report ID.", "danger")
            return render_template("track.html", report=None, history=[])
        with db() as conn:
            report = conn.execute("SELECT * FROM reports WHERE id=?", (rid,)).fetchone()
            if report:
                history = conn.execute("SELECT * FROM history WHERE report_id=? ORDER BY id", (rid,)).fetchall()
        if not report: flash("No report found with that ID.", "warning")
    return render_template("track.html", report=report, history=history)

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        if not ADMIN_PASSWORD_HASH:
            flash("Admin access is not configured. Set ADMIN_PASSWORD_HASH in your environment.", "danger")
        elif check_password_hash(ADMIN_PASSWORD_HASH, request.form.get("password", "")):
            session["admin"] = True
            return redirect(request.args.get("next") or url_for("dashboard"))
        else: flash("Incorrect password.", "danger")
    return render_template("admin_login.html")

@app.route("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/admin")
@admin_required
def dashboard():
    category, status = request.args.get("category", ""), request.args.get("status", "")
    query, params = "SELECT * FROM reports WHERE 1=1", []
    if category in CATEGORIES: query += " AND ai_category=?"; params.append(category)
    if status in STATUSES: query += " AND status=?"; params.append(status)
    query += " ORDER BY priority DESC, id DESC"
    with db() as conn:
        reports = conn.execute(query, params).fetchall()
        counts = {s: conn.execute("SELECT COUNT(*) FROM reports WHERE status=?", (s,)).fetchone()[0] for s in STATUSES}
    return render_template("dashboard.html", reports=reports, counts=counts, selected_category=category, selected_status=status)

@app.route("/admin/report/<int:rid>/status", methods=["POST"])
@admin_required
def update_status(rid):
    status = request.form.get("status", "")
    note = request.form.get("note", "").strip()[:250] or "Status updated by administrator"
    if status not in STATUSES: abort(400)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with db() as conn:
        if not conn.execute("SELECT id FROM reports WHERE id=?", (rid,)).fetchone(): abort(404)
        conn.execute("UPDATE reports SET status=? WHERE id=?", (status, rid))
        conn.execute("INSERT INTO history(report_id,status,note,changed_at) VALUES(?,?,?,?)", (rid, status, note, now))
    flash(f"Report #{rid} updated.", "success")
    return redirect(url_for("dashboard"))

@app.get("/health")
def health():
    return {"status": "ok"}

init_db()
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", 5000)), debug=os.getenv("FLASK_DEBUG") == "true")
