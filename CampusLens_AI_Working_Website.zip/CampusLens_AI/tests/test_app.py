import os, tempfile, unittest
import app as module

class CampusLensTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(delete=False); self.tmp.close()
        self.old_path = module.DB_PATH
        module.DB_PATH = self.tmp.name
        module.init_db()
        module.app.config.update(TESTING=True, SECRET_KEY="test-secret")
        self.client = module.app.test_client()
    def tearDown(self):
        module.DB_PATH = self.old_path
        try: os.unlink(self.tmp.name)
        except OSError: pass
    def test_home(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"CampusLens", r.data)
    def test_classify(self):
        self.assertEqual(module.classify("Wheelchair ramp blocked"), "Accessibility")
    def test_score(self):
        self.assertEqual(module.score(80,100,60,40)[0],80)
    def test_submit_and_track(self):
        r = self.client.post("/report", data={"title":"Ramp blocked","description":"Wheelchair ramp is blocked","location":"Main building","category":"Other","urgency":"80","accessibility":"100","disruption":"60","recurrence":"40"})
        self.assertEqual(r.status_code,200)
        self.assertIn(b"YOUR REPORT ID",r.data)
        t = self.client.get("/track?id=1")
        self.assertEqual(t.status_code,200)
        self.assertIn(b"Ramp blocked",t.data)
    def test_admin_protected(self):
        r = self.client.get("/admin")
        self.assertEqual(r.status_code,302)

if __name__ == "__main__": unittest.main()
