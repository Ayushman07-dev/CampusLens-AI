# CampusLens AI — Working Flask Website

A responsive campus issue reporting prototype with keyword-based category suggestions, explainable priority scoring, duplicate-report suggestions, report tracking, and an authenticated admin dashboard.

## Run on Windows / VS Code
1. Install Python 3.11 or 3.12.
2. Open this folder in VS Code.
3. In the VS Code terminal:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   .\.venv\Scripts\python.exe app.py
   ```
4. Open `http://127.0.0.1:5000`.

## Configure admin access locally
Generate a password hash:
```powershell
.\.venv\Scripts\python.exe -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('ChooseYourOwnStrongPassword'))"
```
Set environment variables in the same terminal before starting the app:
```powershell
$env:SECRET_KEY = "replace-with-a-long-random-secret"
$env:ADMIN_PASSWORD_HASH = "paste-hash-here"
.\.venv\Scripts\python.exe app.py
```
Use your own strong password; do not commit `.env` or secrets.

## Pages
- `/` home dashboard
- `/report` submit issue
- `/track` track by report ID
- `/admin/login` admin login
- `/admin` admin dashboard (requires configured password)
- `/health` deployment health check

## Deployment
Push the files to your own GitHub repository. Create a Render Web Service from the repo; `render.yaml` supplies build/start settings. Set `ADMIN_PASSWORD_HASH` in the Render environment to a Werkzeug hash generated locally and keep `SECRET_KEY` private. Deploy, then test the provided URL.

**Persistence warning:** SQLite data may not survive redeploys on hosts without a persistent disk. For long-lived deployment, configure persistent storage or use PostgreSQL. Confirm all live pages and admin access work before submitting the URL.

## Honest AI description
This starter uses transparent keyword rules for category suggestions, a weighted score, and word-overlap similarity. It does not contain a trained ML model or image recognition. Do not claim a trained model or measured accuracy unless you add and evaluate one.
