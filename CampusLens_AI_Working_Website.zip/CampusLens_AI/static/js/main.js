document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".impact-range").forEach((input) => {
    const output = document.getElementById(`${input.id}-value`);
    const update = () => { if (output) output.value = input.value; };
    input.addEventListener("input", update); update();
  });
  document.querySelectorAll("[data-copy]").forEach((button) => {
    button.addEventListener("click", async () => {
      const value = button.dataset.copy;
      try {
        await navigator.clipboard.writeText(value);
        const old = button.textContent; button.textContent = "Copied!";
        setTimeout(() => button.textContent = old, 1300);
      } catch { window.prompt("Copy report ID:", value); }
    });
  });
});
